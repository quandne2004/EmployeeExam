﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EmployeeExam;

namespace EmployeeExam.Data
{
    public class EmployeeExamContext : DbContext
    {
        public EmployeeExamContext (DbContextOptions<EmployeeExamContext> options)
            : base(options)
        {
        }

        public DbSet<EmployeeExam.Employee> Employee { get; set; } = default!;
    }
}
